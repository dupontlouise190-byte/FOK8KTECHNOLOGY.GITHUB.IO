
import React from 'react';
import { Play, Info, Calendar } from 'lucide-react';
import { Movie } from '../types';

interface HeroProps {
  movie: Movie;
}

const Hero: React.FC<HeroProps> = ({ movie }) => {
  return (
    <div className="relative h-[85vh] w-full overflow-hidden">
      <div className="absolute inset-0">
        <img 
          src={movie.backdropUrl} 
          alt={movie.title}
          className="w-full h-full object-cover transition-all duration-700 scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/20 to-[#0a0a0a]/60"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a0a] via-transparent to-transparent"></div>
      </div>

      <div className="absolute bottom-40 left-0 right-0 px-4 md:px-12 max-w-7xl mx-auto">
        <div className="max-w-2xl space-y-6">
          {movie.isEvent && (
            <div className="inline-flex items-center gap-2 bg-red-600/90 backdrop-blur text-white px-3 py-1 rounded text-xs font-bold uppercase tracking-widest">
              <Calendar size={14} /> Global Event
            </div>
          )}
          <h1 className="text-5xl md:text-7xl font-extrabold leading-tight tracking-tight drop-shadow-2xl">
            {movie.title}
          </h1>
          <div className="flex items-center gap-4 text-lg font-medium">
            <span className="text-green-500">{movie.rating} Match</span>
            <span className="text-gray-400">{movie.year}</span>
            <span className="border border-gray-500 px-1 text-xs rounded">4K</span>
            <span className="text-gray-400">{movie.duration}</span>
          </div>
          <p className="text-xl text-gray-200 line-clamp-3 leading-relaxed drop-shadow">
            {movie.description}
          </p>
          <div className="flex flex-wrap items-center gap-4 pt-4">
            <button className="flex items-center gap-2 bg-white text-black px-8 py-3.5 rounded font-bold hover:bg-white/90 transition text-lg shadow-xl">
              <Play size={24} fill="currentColor" /> Play Now
            </button>
            <button className="flex items-center gap-2 bg-white/20 backdrop-blur-md text-white px-8 py-3.5 rounded font-bold hover:bg-white/30 transition text-lg shadow-xl">
              <Info size={24} /> Watch More Info
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
