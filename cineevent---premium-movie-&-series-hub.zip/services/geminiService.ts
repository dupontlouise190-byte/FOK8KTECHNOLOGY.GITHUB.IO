
import { GoogleGenAI, Type } from "@google/genai";
import { RecommendationResponse } from "../types";

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  }

  async getRecommendations(mood: string, preferences: string): Promise<RecommendationResponse> {
    const response = await this.ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Suggest 4 movies or series based on: Mood: ${mood}, Preferences: ${preferences}. 
                 Include a match score from 0-100 based on how well it fits.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            movies: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  year: { type: Type.STRING },
                  description: { type: Type.STRING },
                  genre: { type: Type.STRING },
                  matchScore: { type: Type.NUMBER }
                },
                required: ["title", "year", "description", "genre", "matchScore"]
              }
            }
          }
        }
      }
    });

    try {
      return JSON.parse(response.text || '{"movies": []}');
    } catch (e) {
      console.error("Failed to parse AI response", e);
      return { movies: [] };
    }
  }
}

export const geminiService = new GeminiService();
