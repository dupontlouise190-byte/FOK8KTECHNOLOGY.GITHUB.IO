
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Play, Plus, ThumbsUp, Share2 } from 'lucide-react';
import { FEATURED_MOVIES } from '../constants';

const MovieDetail: React.FC = () => {
  const { id } = useParams();
  const movie = FEATURED_MOVIES.find(m => m.id === id) || FEATURED_MOVIES[0];

  return (
    <div className="min-h-screen bg-[#0a0a0a] pt-24 px-4 md:px-12">
      <div className="max-w-7xl mx-auto">
        <Link to="/" className="inline-flex items-center gap-2 text-gray-400 hover:text-white transition mb-8">
          <ArrowLeft size={20} /> Back to Browse
        </Link>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          <div className="lg:col-span-1">
            <img src={movie.imageUrl} alt={movie.title} className="w-full rounded-2xl shadow-2xl border border-white/10" />
            <div className="flex gap-4 mt-6">
              <button className="flex-1 bg-white text-black font-bold py-3 rounded-lg hover:bg-white/90 transition flex items-center justify-center gap-2">
                <Play size={20} fill="currentColor" /> Play
              </button>
              <button className="p-3 bg-white/10 rounded-lg border border-white/10 hover:bg-white/20 transition">
                <Plus size={24} />
              </button>
              <button className="p-3 bg-white/10 rounded-lg border border-white/10 hover:bg-white/20 transition">
                <ThumbsUp size={24} />
              </button>
            </div>
          </div>
          
          <div className="lg:col-span-2 space-y-8">
            <div>
              <h1 className="text-5xl md:text-6xl font-black mb-4 tracking-tight">{movie.title}</h1>
              <div className="flex flex-wrap items-center gap-4 text-sm font-bold">
                <span className="text-green-500">{movie.rating} Match</span>
                <span className="text-gray-400">{movie.year}</span>
                <span className="border border-gray-600 px-1.5 rounded-sm">18+</span>
                <span className="text-gray-400">{movie.duration}</span>
                <div className="flex gap-2">
                  {movie.genre.map(g => (
                    <span key={g} className="bg-white/5 px-2 py-0.5 rounded border border-white/5">{g}</span>
                  ))}
                </div>
              </div>
            </div>

            <p className="text-xl text-gray-300 leading-relaxed">
              {movie.description}
            </p>

            <div className="pt-8 border-t border-white/5 space-y-4">
              <div className="flex items-center gap-4">
                <span className="text-gray-500 font-bold w-24">Cast:</span>
                <span className="text-gray-300">Jonathan Doe, Sarah Smith, Michael Brown, Emma Wilson</span>
              </div>
              <div className="flex items-center gap-4">
                <span className="text-gray-500 font-bold w-24">Director:</span>
                <span className="text-gray-300">Alexandra Rodriguez</span>
              </div>
              <div className="flex items-center gap-4">
                <span className="text-gray-500 font-bold w-24">Release:</span>
                <span className="text-gray-300">August 24, {movie.year}</span>
              </div>
            </div>

            <div className="flex items-center gap-4 pt-4">
              <button className="flex items-center gap-2 text-gray-400 hover:text-white transition font-bold">
                <Share2 size={20} /> Share
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MovieDetail;
