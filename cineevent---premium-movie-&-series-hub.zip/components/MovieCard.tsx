
import React from 'react';
import { Play, Plus, ThumbsUp, ChevronDown } from 'lucide-react';
import { Movie } from '../types';

interface MovieCardProps {
  movie: Movie;
  onClick: () => void;
}

const MovieCard: React.FC<MovieCardProps> = ({ movie, onClick }) => {
  return (
    <div 
      className="group relative flex-none w-[200px] md:w-[260px] aspect-[2/3] rounded-lg overflow-hidden cursor-pointer transition-transform duration-300 hover:scale-105 active:scale-95"
      onClick={onClick}
    >
      <img 
        src={movie.imageUrl} 
        alt={movie.title} 
        className="w-full h-full object-cover rounded-lg shadow-lg grayscale-[20%] group-hover:grayscale-0 transition-all duration-500"
        loading="lazy"
      />
      
      {/* Badge */}
      <div className="absolute top-2 left-2 z-10">
        <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
          movie.type === 'series' ? 'bg-blue-600 text-white' : 'bg-red-600 text-white'
        }`}>
          {movie.type}
        </span>
      </div>

      {/* Overlay on hover */}
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-4">
        <h3 className="text-lg font-bold mb-2 translate-y-4 group-hover:translate-y-0 transition-transform duration-300">{movie.title}</h3>
        <div className="flex gap-2 translate-y-4 group-hover:translate-y-0 transition-transform duration-300 delay-75">
          <button className="bg-white text-black p-2 rounded-full hover:bg-gray-200 transition shadow-lg">
            <Play size={16} fill="currentColor" />
          </button>
          <button className="bg-white/20 backdrop-blur-md p-2 rounded-full hover:bg-white/30 transition border border-white/20">
            <Plus size={16} />
          </button>
          <button className="bg-white/20 backdrop-blur-md p-2 rounded-full hover:bg-white/30 transition border border-white/20">
            <ThumbsUp size={16} />
          </button>
          <button className="ml-auto bg-white/20 backdrop-blur-md p-2 rounded-full hover:bg-white/30 transition border border-white/20">
            <ChevronDown size={16} />
          </button>
        </div>
        <div className="mt-3 flex items-center gap-2 text-[10px] font-bold uppercase tracking-wider text-green-400 opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-150">
          <span>{movie.rating} Match</span>
          <span className="text-gray-400">•</span>
          <span>{movie.duration}</span>
        </div>
      </div>
    </div>
  );
};

export default MovieCard;
