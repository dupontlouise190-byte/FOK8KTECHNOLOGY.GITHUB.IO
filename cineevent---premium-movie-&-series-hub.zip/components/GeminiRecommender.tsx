
import React, { useState } from 'react';
import { Sparkles, Loader2, PlayCircle } from 'lucide-react';
import { geminiService } from '../services/geminiService';
import { RecommendationResponse } from '../types';

const GeminiRecommender: React.FC = () => {
  const [mood, setMood] = useState('');
  const [preferences, setPreferences] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<RecommendationResponse | null>(null);

  const handleRecommend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mood || !preferences) return;
    
    setLoading(true);
    try {
      const data = await geminiService.getRecommendations(mood, preferences);
      setResults(data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <form onSubmit={handleRecommend} className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="text-sm font-semibold text-gray-400">What's your mood?</label>
          <input 
            type="text" 
            value={mood}
            onChange={(e) => setMood(e.target.value)}
            placeholder="e.g. Melancholic, Excited, Philosophical" 
            className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:ring-2 focus:ring-red-600 outline-none transition"
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-semibold text-gray-400">What do you like?</label>
          <input 
            type="text" 
            value={preferences}
            onChange={(e) => setPreferences(e.target.value)}
            placeholder="e.g. 80s sci-fi, mind-bending plots, noir" 
            className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:ring-2 focus:ring-red-600 outline-none transition"
          />
        </div>
        <button 
          disabled={loading}
          className="md:col-span-2 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2 transition shadow-lg"
        >
          {loading ? <Loader2 className="animate-spin" /> : <Sparkles size={20} />}
          Get AI Recommendations
        </button>
      </form>

      {results && results.movies.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
          {results.movies.map((movie, idx) => (
            <div key={idx} className="bg-white/5 border border-white/10 rounded-2xl p-6 flex flex-col gap-3 group hover:bg-white/10 transition">
              <div className="flex justify-between items-start">
                <h3 className="text-xl font-bold group-hover:text-red-500 transition">{movie.title}</h3>
                <span className="text-xs font-bold bg-green-500/20 text-green-400 px-2 py-1 rounded">
                  {movie.matchScore}% Match
                </span>
              </div>
              <div className="flex gap-2 text-xs text-gray-400 font-medium">
                <span>{movie.year}</span>
                <span>•</span>
                <span>{movie.genre}</span>
              </div>
              <p className="text-sm text-gray-300 leading-relaxed line-clamp-2">
                {movie.description}
              </p>
              <button className="mt-4 flex items-center gap-2 text-sm font-bold text-white hover:text-red-400 transition">
                <PlayCircle size={18} /> Watch More Details
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default GeminiRecommender;
