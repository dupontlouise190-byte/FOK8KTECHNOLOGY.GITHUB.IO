
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Search, Bell, User, Menu, X } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'bg-[#0a0a0a]/90 backdrop-blur-md border-b border-white/5 py-3' : 'bg-transparent py-5'
    }`}>
      <div className="max-w-7xl mx-auto px-4 md:px-12 flex items-center justify-between">
        <div className="flex items-center gap-10">
          <Link to="/" className="text-3xl font-extrabold tracking-tighter text-red-600 flex items-center gap-2">
            <span className="bg-red-600 text-white px-2 py-0.5 rounded">C</span>
            CINEEVENT
          </Link>
          <div className="hidden md:flex items-center gap-6 text-sm font-medium text-gray-300">
            <Link to="/" className="hover:text-white transition">Home</Link>
            <Link to="/" className="hover:text-white transition">Events</Link>
            <Link to="/" className="hover:text-white transition">Series</Link>
            <Link to="/" className="hover:text-white transition">Movies</Link>
            <Link to="/" className="hover:text-white transition">New & Popular</Link>
          </div>
        </div>

        <div className="flex items-center gap-5">
          <div className="hidden sm:flex items-center bg-white/10 px-3 py-1.5 rounded-full border border-white/5">
            <Search size={18} className="text-gray-400" />
            <input 
              type="text" 
              placeholder="Titles, people, genres..." 
              className="bg-transparent border-none focus:ring-0 text-sm ml-2 w-48 placeholder:text-gray-500"
            />
          </div>
          <Bell size={20} className="text-gray-300 cursor-pointer hover:text-white" />
          <div className="w-8 h-8 rounded bg-gradient-to-br from-indigo-500 to-purple-500 cursor-pointer"></div>
          <button 
            className="md:hidden text-white" 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-[#0a0a0a] border-b border-white/10 p-6 flex flex-col gap-4 animate-in fade-in slide-in-from-top-4">
          <Link to="/" className="text-lg" onClick={() => setMobileMenuOpen(false)}>Home</Link>
          <Link to="/" className="text-lg" onClick={() => setMobileMenuOpen(false)}>Events</Link>
          <Link to="/" className="text-lg" onClick={() => setMobileMenuOpen(false)}>Series</Link>
          <Link to="/" className="text-lg" onClick={() => setMobileMenuOpen(false)}>Movies</Link>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
