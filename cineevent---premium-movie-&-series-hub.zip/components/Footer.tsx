
import React from 'react';
import { Facebook, Twitter, Instagram, Youtube } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-[#0a0a0a] pt-20 pb-10 px-4 md:px-12 border-t border-white/5">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
          <div className="space-y-4">
            <h4 className="font-bold text-gray-400 uppercase text-xs tracking-widest">Platform</h4>
            <ul className="space-y-2 text-sm text-gray-500">
              <li><a href="#" className="hover:text-white transition">Account</a></li>
              <li><a href="#" className="hover:text-white transition">Redeem Code</a></li>
              <li><a href="#" className="hover:text-white transition">Buy Gift Card</a></li>
              <li><a href="#" className="hover:text-white transition">Media Center</a></li>
            </ul>
          </div>
          <div className="space-y-4">
            <h4 className="font-bold text-gray-400 uppercase text-xs tracking-widest">Help</h4>
            <ul className="space-y-2 text-sm text-gray-500">
              <li><a href="#" className="hover:text-white transition">Help Center</a></li>
              <li><a href="#" className="hover:text-white transition">Terms of Use</a></li>
              <li><a href="#" className="hover:text-white transition">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-white transition">Contact Us</a></li>
            </ul>
          </div>
          <div className="space-y-4">
            <h4 className="font-bold text-gray-400 uppercase text-xs tracking-widest">Content</h4>
            <ul className="space-y-2 text-sm text-gray-500">
              <li><a href="#" className="hover:text-white transition">Movie Events</a></li>
              <li><a href="#" className="hover:text-white transition">Original Series</a></li>
              <li><a href="#" className="hover:text-white transition">Documentaries</a></li>
              <li><a href="#" className="hover:text-white transition">Trailers</a></li>
            </ul>
          </div>
          <div className="space-y-6">
            <h4 className="font-bold text-gray-400 uppercase text-xs tracking-widest">Connect</h4>
            <div className="flex gap-4">
              <Facebook className="text-gray-500 hover:text-white cursor-pointer transition" />
              <Instagram className="text-gray-500 hover:text-white cursor-pointer transition" />
              <Twitter className="text-gray-500 hover:text-white cursor-pointer transition" />
              <Youtube className="text-gray-500 hover:text-white cursor-pointer transition" />
            </div>
            <button className="border border-gray-600 px-4 py-2 text-xs font-bold text-gray-400 hover:text-white hover:border-white transition uppercase tracking-widest">
              Service Code
            </button>
          </div>
        </div>
        <div className="text-center text-xs text-gray-600 pt-8 border-t border-white/5">
          &copy; {new Date().getFullYear()} CINEEVENT ENTERTAINMENT. ALL RIGHTS RESERVED.
        </div>
      </div>
    </footer>
  );
};

export default Footer;
