
import React, { useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import MovieCard from './MovieCard';
import { Movie } from '../types';

interface MovieGridProps {
  movies: Movie[];
  onSelect: (movie: Movie) => void;
}

const MovieGrid: React.FC<MovieGridProps> = ({ movies, onSelect }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const { scrollLeft, clientWidth } = scrollRef.current;
      const scrollTo = direction === 'left' ? scrollLeft - clientWidth : scrollLeft + clientWidth;
      scrollRef.current.scrollTo({ left: scrollTo, behavior: 'smooth' });
    }
  };

  return (
    <div className="relative group/grid">
      <button 
        onClick={() => scroll('left')}
        className="absolute left-0 top-1/2 -translate-y-1/2 z-20 bg-black/50 p-2 rounded-full opacity-0 group-hover/grid:opacity-100 transition hover:bg-black/80 -ml-4"
      >
        <ChevronLeft size={32} />
      </button>

      <div 
        ref={scrollRef}
        className="flex gap-4 overflow-x-auto scrollbar-hide pb-4 snap-x"
        style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
      >
        {movies.map((movie) => (
          <div key={movie.id} className="snap-start">
            <MovieCard movie={movie} onClick={() => onSelect(movie)} />
          </div>
        ))}
        {/* Placeholder for more */}
        <div className="flex-none w-[200px] md:w-[260px] aspect-[2/3] rounded-lg border-2 border-dashed border-white/10 flex flex-col items-center justify-center gap-4 text-gray-500 hover:text-gray-300 hover:border-white/30 transition cursor-pointer group/more">
           <div className="p-4 rounded-full bg-white/5 group-hover/more:scale-110 transition duration-300">
             <ChevronRight size={32} />
           </div>
           <span className="font-bold text-sm">Watch More</span>
        </div>
      </div>

      <button 
        onClick={() => scroll('right')}
        className="absolute right-0 top-1/2 -translate-y-1/2 z-20 bg-black/50 p-2 rounded-full opacity-0 group-hover/grid:opacity-100 transition hover:bg-black/80 -mr-4"
      >
        <ChevronRight size={32} />
      </button>
    </div>
  );
};

export default MovieGrid;
